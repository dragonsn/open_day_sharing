// Fill out your copyright notice in the Description page of Project Settings.

#include "NextRTS.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, NextRTS, "NextRTS" );
